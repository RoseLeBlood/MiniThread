#!/bin/zsh
RELEASE="$(pwd)/release"

function clean() {
    cd $RELEASE
    rm -r *
}
function build() {
    pio package pack ../
    MINITHREAD_FILE=($(ls | grep miniThread-2* )) 
    printf "\n\e[1;32mAdd \"lib_deps = $MINITHREAD_FILE\" to your platformio.ini\n\n\e[0m"
}

function use_info() {
    printf "\e[3;1mplatformio.ini\e[0m\n"
    printf "\e[1;32m[env:esp-wrover-kit]\n"
    printf "\e[1;34mplatform \e[0m= espressif32\n"
    printf "\e[1;34mboard \e[0m= esp-wrover-kit\n"
    printf "\e[1;34mframework \e[0m= espidf\n"
    printf "\e[1;34mlib_deps \e[0m=$RELEASE/$MINITHREAD_FILE\n"
}


 